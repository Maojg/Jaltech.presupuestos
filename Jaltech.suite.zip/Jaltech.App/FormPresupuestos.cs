﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Jaltech.Data;
using Jaltech.Core.Models;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using System.Data;
using System.Globalization;

namespace Jaltech.App
{
    public partial class FormPresupuestos : Form
    {
        private readonly JaltechDbContext _context;

        public FormPresupuestos(JaltechDbContext context)
        {
            InitializeComponent();
            _context = context;
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        private void btnCargarExcel_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new()
            {
                Filter = "Excel Files|*.xlsx;*.xls",
                Title = "Seleccionar archivo Excel"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                var filePath = ofd.FileName;
                var data = LeerDatosDesdeExcel(filePath);
                dgvPresupuestos.DataSource = data;
            }
        }

        private List<DimPresupuestoZonal> LeerDatosDesdeExcel(string filePath)
        {
            var lista = new List<DimPresupuestoZonal>();
            using var package = new ExcelPackage(new FileInfo(filePath));
            var worksheet = package.Workbook.Worksheets[0];
            int rows = worksheet.Dimension.Rows;

            for (int i = 3; i <= rows; i++) // Asume que los encabezados están en fila 2
            {
                if (string.IsNullOrWhiteSpace(worksheet.Cells[i, 1].Text)) continue;

                var zona = worksheet.Cells[i, 1].Text;
                var salarioBasico = decimal.Parse(worksheet.Cells[i, 2].Text, CultureInfo.InvariantCulture);
                var prestacional = decimal.Parse(worksheet.Cells[i, 3].Text, CultureInfo.InvariantCulture);
                var promedioComisiones = decimal.Parse(worksheet.Cells[i, 4].Text, CultureInfo.InvariantCulture);
                var salarioTotal = decimal.Parse(worksheet.Cells[i, 5].Text, CultureInfo.InvariantCulture);

                var presupuesto = new DimPresupuestoZonal
                {
                    Anio = DateTime.Now.Year,
                    Mes = DateTime.Now.Month,
                    Zona = zona,
                    SalarioBasico = salarioBasico,
                    Prestacional = prestacional,
                    PromedioComisiones = promedioComisiones,
                    SalarioPromedioTotal = salarioTotal,
                    BonoCumplVentas = ParseDecimal(worksheet.Cells[i, 7].Text),
                    BonoBasik = ParseDecimal(worksheet.Cells[i, 8].Text),
                    BonoCelulares = ParseDecimal(worksheet.Cells[i, 9].Text),
                    BonoBod = ParseDecimal(worksheet.Cells[i, 10].Text),
                    BonoDulces = ParseDecimal(worksheet.Cells[i, 11].Text),
                    ClientesActivos = ParseInt(worksheet.Cells[i, 12].Text),
                    KPIReguladores = ParseDecimal(worksheet.Cells[i, 13].Text),
                    TotalBonosMes = ParseDecimal(worksheet.Cells[i, 14].Text),
                    TotalSalario = ParseDecimal(worksheet.Cells[i, 16].Text),
                    FechaCarga = DateTime.Now
                };

                lista.Add(presupuesto);
            }

            return lista;
        }

        private void btnGuardarBD_Click(object sender, EventArgs e)
        {
            if (dgvPresupuestos.DataSource is not List<DimPresupuestoZonal> data) return;

            foreach (var item in data)
            {
                var existe = _context.PresupuestosZonales.Any(p =>
                    p.Zona == item.Zona && p.Mes == item.Mes && p.Anio == item.Anio);

                if (!existe)
                    _context.PresupuestosZonales.Add(item);
            }

            _context.SaveChanges();
            MessageBox.Show("Datos guardados correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private decimal ParseDecimal(string value)
        {
            decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result);
            return result;
        }

        private int ParseInt(string value)
        {
            int.TryParse(value, out var result);
            return result;
        }
    }
}
