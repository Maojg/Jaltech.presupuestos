﻿using Microsoft.EntityFrameworkCore;
using Jaltech.Core.Models;

namespace Jaltech.Data
{
    public class JaltechDbContext : DbContext
    {
        public JaltechDbContext(DbContextOptions<JaltechDbContext> options) : base(options) { }

        public DbSet<PresupuestoZonal> Presupuestos { get; set; }
    }
}
