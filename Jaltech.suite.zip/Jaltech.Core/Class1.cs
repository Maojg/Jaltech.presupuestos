﻿namespace Jaltech.Core.Models
{
    public class PresupuestoZonal
    {
        public int Id { get; set; }
        public int Anio { get; set; }
        public int Mes { get; set; }
        public string Zona { get; set; } = string.Empty;
        public decimal PptoVentasTotal { get; set; }
        public decimal BonoCumplimiento { get; set; }
        public decimal BonoBasik { get; set; }
        public int ClientesActivos { get; set; }
        public decimal TotalBonosMes { get; set; }
        public decimal SalarioEstimado { get; set; }
        public DateTime FechaCarga { get; set; } = DateTime.Now;
    }
}
